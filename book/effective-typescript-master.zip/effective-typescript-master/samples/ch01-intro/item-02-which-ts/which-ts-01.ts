// tsConfig: {"noImplicitAny":false,"strictNullChecks":false}

function add(a, b) {
  return a + b;
}
add(10, null);
