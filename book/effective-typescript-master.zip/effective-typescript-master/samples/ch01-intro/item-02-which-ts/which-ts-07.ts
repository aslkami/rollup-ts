// tsConfig: {"noImplicitAny":true,"strictNullChecks":true}

const x: number | null = null;
