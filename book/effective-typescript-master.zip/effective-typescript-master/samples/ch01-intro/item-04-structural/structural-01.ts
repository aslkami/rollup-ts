interface Vector2D {
  x: number;
  y: number;
}
