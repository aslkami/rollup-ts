function turnLightOn() {}
function turnLightOff() {}
