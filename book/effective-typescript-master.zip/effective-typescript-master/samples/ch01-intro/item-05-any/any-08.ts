interface ComponentProps {
  onSelectItem: (id: number) => void;
}
