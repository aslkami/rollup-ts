function greet(who: string) {
  console.log('Hello', who);
}
