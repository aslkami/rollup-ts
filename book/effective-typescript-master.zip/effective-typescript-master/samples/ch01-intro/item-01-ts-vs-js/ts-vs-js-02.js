let city = 'new york city';
console.log(city.toUppercase());
