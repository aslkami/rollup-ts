const x = 2 + '3';  // OK, type is string
const y = '2' + 3;  // OK, type is string
