interface Identified {
  id: string;
}
