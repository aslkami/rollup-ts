type AB = 'A' | 'B';
type AB12 = 'A' | 'B' | 12;
