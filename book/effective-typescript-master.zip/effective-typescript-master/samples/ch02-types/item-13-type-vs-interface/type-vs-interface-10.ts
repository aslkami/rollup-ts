type AorB = 'a' | 'b';
