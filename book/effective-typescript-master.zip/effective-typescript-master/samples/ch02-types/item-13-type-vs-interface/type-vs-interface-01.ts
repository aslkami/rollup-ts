type TState = {
  name: string;
  capital: string;
}
