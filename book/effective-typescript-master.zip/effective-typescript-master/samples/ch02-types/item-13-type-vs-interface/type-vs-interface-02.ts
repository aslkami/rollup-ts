type TState = {
  name: string;
  capital: string;
}
interface IState {
  name: string;
  capital: string;
}
