interface Room {
  numDoors: number;
  ceilingHeightFt: number;
}
function setDarkMode() {}
