const xs = [1, 2, 3];
xs.forEach((x, i) => {
  i;  // Type is number
  x;  // Type is number
});
