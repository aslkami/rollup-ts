interface Person {
  first: string;
  last: string;
}
function email(options: {person: Person, subject: string, body: string}) {
  // ...
}
