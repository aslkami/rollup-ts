interface Person {
  first: string;
  last: string;
}
