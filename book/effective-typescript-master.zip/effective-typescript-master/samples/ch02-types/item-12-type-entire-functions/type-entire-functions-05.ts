const responseP = fetch('/quote?by=Mark+Twain');  // Type is Promise<Response>
