declare function fetch(
  input: RequestInfo, init?: RequestInit
): Promise<Response>;
