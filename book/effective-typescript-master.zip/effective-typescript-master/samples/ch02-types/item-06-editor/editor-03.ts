declare var Request: {
    prototype: Request;
    new(input: RequestInfo, init?: RequestInit): Request;
};
