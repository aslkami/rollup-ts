type Expression1 = any;
type Expression2 = number | string | any[];
