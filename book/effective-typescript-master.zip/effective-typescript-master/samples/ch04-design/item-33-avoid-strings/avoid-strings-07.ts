/** What type of environment was this recording made in?  */
type RecordingType = 'live' | 'studio';
