interface Person {
  name: string;
  birth?: {
    place: string;
    date: Date;
  }
}
