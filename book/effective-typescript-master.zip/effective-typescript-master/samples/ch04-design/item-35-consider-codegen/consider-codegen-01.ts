interface BoundingBox {
  lat: [number, number];
  lng: [number, number];
}
