interface State {
  pageText: string;
  isLoading: boolean;
  error?: string;
}
declare let currentPage: string;
function getUrlForPage(p: string) { return ''; }
