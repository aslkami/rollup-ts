interface State {
  pageText: string;
  isLoading: boolean;
  error?: string;
}
declare let currentPage: string;
