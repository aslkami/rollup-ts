function sort(nums: readonly number[]) { /* ... */ }
