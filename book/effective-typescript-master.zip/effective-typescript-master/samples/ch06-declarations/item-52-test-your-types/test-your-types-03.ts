const square = (x: number) => x * x;
