declare function makeButton(props: {text: string, onClick: () => void }): void;
