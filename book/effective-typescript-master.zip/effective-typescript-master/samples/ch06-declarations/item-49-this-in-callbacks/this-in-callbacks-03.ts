class C {
  vals = [1, 2, 3];
  logSquares() {
    for (const val of this.vals) {
      console.log(val * val);
    }
  }
}
const c = new C();
const method = c.logSquares;
method.call(c);  // Logs the squares again
