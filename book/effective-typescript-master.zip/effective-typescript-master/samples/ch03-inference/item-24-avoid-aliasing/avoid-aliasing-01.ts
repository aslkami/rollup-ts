const borough = {name: 'Brooklyn', location: [40.688, -73.979]};
const loc = borough.location;
