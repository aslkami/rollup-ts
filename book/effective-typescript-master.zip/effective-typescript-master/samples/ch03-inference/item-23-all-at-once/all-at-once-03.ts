interface Point { x: number; y: number; }
const pt = {
  x: 3,
  y: 4,
};  // OK
