interface Point { x: number; y: number; }
