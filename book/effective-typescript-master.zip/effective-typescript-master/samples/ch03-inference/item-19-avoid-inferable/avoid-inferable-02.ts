let x = 12;
