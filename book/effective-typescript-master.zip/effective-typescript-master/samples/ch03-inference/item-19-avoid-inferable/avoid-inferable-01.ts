let x: number = 12;
