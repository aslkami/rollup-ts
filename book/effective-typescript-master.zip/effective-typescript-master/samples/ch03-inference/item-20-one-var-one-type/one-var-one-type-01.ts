function fetchProduct(id: string) {}
function fetchProductBySerialNumber(id: number) {}
