function somethingDangerous() {}
