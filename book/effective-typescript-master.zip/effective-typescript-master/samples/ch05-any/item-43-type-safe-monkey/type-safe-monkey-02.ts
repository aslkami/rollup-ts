(document as any).monkey = 'Tamarin';  // OK
