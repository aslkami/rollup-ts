const utils = {
  buildColumnInfo(s: any, name: string): any {},
};
declare let appState: { dataSchema: unknown };
