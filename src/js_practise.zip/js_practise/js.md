1. inline caching 和 hidden classes [传送门](https://richardartoul.github.io/jekyll/update/2015/04/26/hidden-classes.html)
2. stack overflow 最简单的溢出 便是 函数自身递归调用
3. memory leak 内存泄漏
   - global variable 全局变量
   - event listener `window.addEventListener`
   - setInterval 定时器
4. event loop [传送门](http://latentflip.com/loupe/?code=ZnVuY3Rpb24gcHJpbnRIZWxsbygpIHsNCiAgICBjb25zb2xlLmxvZygnSGVsbG8gZnJvbSBiYXonKTsNCn0NCg0KZnVuY3Rpb24gYmF6KCkgew0KICAgIHNldFRpbWVvdXQocHJpbnRIZWxsbywgMzAwMCk7DQp9DQoNCmZ1bmN0aW9uIGJhcigpIHsNCiAgICBiYXooKTsNCn0NCg0KZnVuY3Rpb24gZm9vKCkgew0KICAgIGJhcigpOw0KfQ0KDQpmb28oKTs%3D!!!PGJ1dHRvbj5DbGljayBtZSE8L2J1dHRvbj4%3D)
